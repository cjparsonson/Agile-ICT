# Script to open programs at startup

& "C:\Users\chris.parsonson.TEAMORANGE\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Outlook.lnk"

& "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Edge.lnk"

& "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\OneNote.lnk"

& "C:\Program Files\WindowsApps\Microsoft.WindowsTerminal_1.16.10262.0_x64__8wekyb3d8bbwe\WindowsTerminal.exe"

