Write-Host "Hello"
$processname = "pwsh"
Get-Process $processname